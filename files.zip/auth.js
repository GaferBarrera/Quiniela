// ============================================================
//  backend/src/routes/auth.js
// ============================================================

import { Router } from 'express';
import bcrypt     from 'bcrypt';
import { pool }   from '../db/pool.js';
import { signToken } from '../middleware/auth.js';

export const authRouter = Router();

// POST /api/auth/register
authRouter.post('/register', async (req, res, next) => {
    const { username, email, password } = req.body;
    if (!username || !email || !password) {
        return res.status(400).json({ error: 'username, email y password son requeridos.' });
    }
    if (password.length < 6) {
        return res.status(400).json({ error: 'La contraseña debe tener al menos 6 caracteres.' });
    }
    try {
        const hash = await bcrypt.hash(password, 12);
        const { rows } = await pool.query(
            `INSERT INTO users (username, email, password_hash)
             VALUES ($1, $2, $3)
             RETURNING id, username, email, role`,
            [username.trim(), email.toLowerCase().trim(), hash]
        );
        const token = signToken({ id: rows[0].id, username: rows[0].username, role: rows[0].role });
        res.status(201).json({ user: rows[0], token });
    } catch (err) {
        if (err.code === '23505') return res.status(409).json({ error: 'El usuario o email ya está registrado.' });
        next(err);
    }
});

// POST /api/auth/login
authRouter.post('/login', async (req, res, next) => {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'email y password requeridos.' });
    try {
        const { rows } = await pool.query(
            'SELECT * FROM users WHERE email = $1', [email.toLowerCase().trim()]
        );
        if (rows.length === 0) return res.status(401).json({ error: 'Credenciales incorrectas.' });
        const valid = await bcrypt.compare(password, rows[0].password_hash);
        if (!valid) return res.status(401).json({ error: 'Credenciales incorrectas.' });

        const token = signToken({ id: rows[0].id, username: rows[0].username, role: rows[0].role });
        res.json({
            user  : { id: rows[0].id, username: rows[0].username, email: rows[0].email, role: rows[0].role },
            token
        });
    } catch (err) { next(err); }
});

// ============================================================
//  backend/src/routes/matches.js
// ============================================================
import { Router as R2 } from 'express';
import { requireAuth }  from '../middleware/auth.js';
export const matchesRouter = R2();

// GET /api/matches — Lista todos los partidos con la
// predicción del usuario autenticado (si existe)
matchesRouter.get('/', requireAuth, async (req, res, next) => {
    try {
        const { rows } = await pool.query(
            `SELECT
                m.id, m.match_number, m.home_team, m.away_team,
                m.home_flag_emoji, m.away_flag_emoji,
                m.stage, m.match_start_utc,
                m.home_score_final, m.away_score_final, m.is_finished,
                (NOW() AT TIME ZONE 'UTC') >= m.match_start_utc AS is_locked,
                p.home_score_pred,
                p.away_score_pred,
                p.points_earned,
                p.submitted_at AS prediction_submitted_at
             FROM matches m
             LEFT JOIN predictions p
                ON p.match_id = m.id AND p.user_id = $1
             ORDER BY m.match_start_utc ASC`,
            [req.user.id]
        );
        res.json(rows);
    } catch (err) { next(err); }
});

// ============================================================
//  backend/src/routes/ranking.js
// ============================================================
import { Router as R3 } from 'express';
import { requireAuth as ra } from '../middleware/auth.js';
export const rankingRouter = R3();

// GET /api/ranking
rankingRouter.get('/', ra, async (req, res, next) => {
    try {
        const { rows } = await pool.query('SELECT * FROM ranking ORDER BY position ASC');
        res.json(rows);
    } catch (err) { next(err); }
});

// ============================================================
//  backend/src/middleware/errorHandler.js
// ============================================================
export function errorHandler(err, _req, res, _next) {
    console.error('[ERROR]', err.message);
    res.status(500).json({ error: 'Error interno del servidor.' });
}
